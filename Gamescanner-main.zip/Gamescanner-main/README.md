![gamescanner5](https://github.com/b00nji/Gamescanner/assets/105116346/255d0fff-2a3f-4ca9-beba-cb49e96e9253)
![gamescanner4](https://github.com/b00nji/Gamescanner/assets/105116346/687183e2-7c57-40d7-aa08-a26fa8ba1f3f)
![gamescanner3](https://github.com/b00nji/Gamescanner/assets/105116346/851fb4a7-f268-4078-b8bb-227bf93c4216)
![gamescanner2](https://github.com/b00nji/Gamescanner/assets/105116346/d25fec0c-aef2-47d0-9949-9a98338ab4ae)
![gamescanner1](https://github.com/b00nji/Gamescanner/assets/105116346/9a77b6f6-7ff1-4a3e-9b6d-6872e6102814)
# Gamescanner
Serverbrowser for ET,ETL and RTCW
About This File
Hello my Enemy Territory friends!

I've read in Discord that new or returning players are looking for servers and that some people don't find the trackbase search very comfortable. Since unfortunately HLSW is no longer looking for servers, I discovered the tool Gamescanner from bdamage http://www.bdamage.se/.

The tool can:

View ETLegacy Servers (Public / Private)
buddy list
Show other ET mods.
View RTCWPro servers

I only updated the master servers for ET and RTCW in the gamedfaults file!

If anyone still knows master server addresses please contact me 
